
from flask import Flask, render_template, request
from deepface import DeepFace
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files["photo"]
        if file:
            filename = secure_filename(file.filename)
            path = os.path.join(UPLOAD_FOLDER, filename)
            file.save(path)

            try:
                result = DeepFace.find(img_path=path, db_path="base_employes", enforce_detection=False)
                if len(result[0]) > 0:
                    name = os.path.basename(result[0].iloc[0]["identity"])
                    return f"<h2>✅ Identifié : {name}</h2><a href='/'>Retour</a>"
                else:
                    return "<h2>❌ Visage non reconnu</h2><a href='/'>Retour</a>"
            except Exception as e:
                return f"<h2>Erreur : {str(e)}</h2><a href='/'>Retour</a>"

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
